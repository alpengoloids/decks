from sys import argv

script, b, c, d = argv
print("Script Name: ", script)
print("second input: ", b)
print("third input: ", c)
print("fourth input: ", d)